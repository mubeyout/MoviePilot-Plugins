"""
ByteMuseServices - ByteMuse探索服务聚合模块

基于 ByteMuse API 的探索数据源插件
提供演员、上新、推荐、榜单、厂牌、搜索等探索服务
"""
from typing import Any, List, Dict, Tuple, Optional
from app.plugins import _PluginBase
from app.core.event import eventmanager, Event
from app.schemas.types import ChainEventType, MediaType
from app.schemas import DiscoverSourceEventData, MediaRecognizeConvertEventData, MediaInfo
from app.core.meta import MetaBase
from app.log import logger

# 导入子模块
from .modules import (
    actors,
    new_releases,
    recommendations,
    rankings,
    studios,
    search
)

MODULE_LABELS = {
    "actors": "演员",
    "new_releases": "上新",
    "recommendations": "推荐",
    "rankings": "榜单",
    "studios": "厂牌",
    "search": "搜索",
}


class ByteMuseServices(_PluginBase):
    # 插件名称
    plugin_name = "ByteMuse探索服务"
    # 插件描述
    plugin_desc = "基于 ByteMuse API 的探索数据源插件，提供演员、上新、推荐、榜单、厂牌、搜索等探索服务。（专注于探索服务，识别功能由 MetatubeSource 处理）"
    # 插件图标
    plugin_icon = "https://raw.githubusercontent.com/KoWming/MoviePilot-Plugins/main/icons/ExploreServices.png"
    # 插件版本
    plugin_version = "3.0.0"  # 重大更新：移除识别功能，专注于探索服务
    # 插件作者
    plugin_author = "Mubey"
    # 作者主页
    author_url = "https://github.com/mubey"
    # 插件配置项ID前缀
    plugin_config_prefix = "bytemuseservices_"
    # 加载顺序
    plugin_order = 13
    # 可使用的用户级别
    auth_level = 1

    # 子模块注册表
    modules = {
        "actors": actors,
        "new_releases": new_releases,
        "recommendations": recommendations,
        "rankings": rankings,
        "studios": studios,
        "search": search,
    }
    enabled_modules: Dict[str, bool] = {}

    # ThePornDB API 配置
    _theporndb_api_token: str = ""

    # ByteMuse API 配置
    _bytemuse_base_url: str = "http://10.0.0.1:3750"
    _bytemuse_username: str = "mubey"
    _bytemuse_password: str = "355492"

    # Metatube API 配置
    _metatube_base_url: str = "http://10.0.0.1:3244"

    def init_plugin(self, config: dict = None):
        if config:
            # 读取模块开关配置
            for name in self.modules:
                self.enabled_modules[name] = config.get(f"{name}_enabled", False)

            # 读取 ThePornDB API 配置
            self._theporndb_api_token = config.get("theporndb_api_token", "")

            # 读取 ByteMuse API 配置
            self._bytemuse_base_url = config.get("bytemuse_base_url", "http://10.0.0.1:3750")
            self._bytemuse_username = config.get("bytemuse_username", "mubey")
            self._bytemuse_password = config.get("bytemuse_password", "355492")

            # 读取 Metatube API 配置
            self._metatube_base_url = config.get("metatube_base_url", "http://10.0.0.1:3244")
        else:
            for name in self.modules:
                self.enabled_modules[name] = False

        logger.info(f"ByteMuseServices 插件初始化完成，已启用模块: {[name for name, enabled in self.enabled_modules.items() if enabled]}")

    def get_state(self) -> bool:
        return any(self.enabled_modules.values())

    def get_form(self) -> Tuple[List[dict], Dict[str, Any]]:
        plugin_names = "、".join(MODULE_LABELS.values())
        form = [
            {
                "component": "VForm",
                "content": [
                    # 探索源开关
                    {
                        "component": "VCard",
                        "props": {"class": "mt-0"},
                        "content": [
                            {
                                "component": "VCardTitle",
                                "props": {"class": "d-flex align-center"},
                                "content": [
                                    {
                                        "component": "VIcon",
                                        "props": {"style": "color: #16b1ff;", "class": "mr-2"},
                                        "text": "mdi-compass-outline"
                                    },
                                    {
                                        "component": "span",
                                        "text": "探索源开关"
                                    }
                                ]
                            },
                            {"component": "VDivider"},
                            {
                                "component": "VCardText",
                                "content": [
                                    {
                                        "component": "VRow",
                                        "content": [
                                            {
                                                "component": "VCol",
                                                "props": {"cols": 12, "sm": 6, "md": 4},
                                                "content": [
                                                    {
                                                        "component": "VSwitch",
                                                        "props": {
                                                            "model": f"{name}_enabled",
                                                            "label": f"{MODULE_LABELS.get(name, name)}",
                                                        },
                                                    }
                                                ],
                                            }
                                            for name in self.modules
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    # API 配置
                    {
                        'component': 'VCard',
                        'props': {
                            'variant': 'flat',
                            'class': 'mt-3',
                            'color': 'surface'
                        },
                        'content': [
                            {
                                'component': 'VCardItem',
                                'props': {
                                    'class': 'px-6 pb-0'
                                },
                                'content': [
                                    {
                                        'component': 'VCardTitle',
                                        'props': {
                                            'class': 'd-flex align-center text-h6'
                                        },
                                        'content': [
                                            {
                                                'component': 'VIcon',
                                                'props': {
                                                    'style': 'color: #16b1ff;',
                                                    'class': 'mr-2'
                                                },
                                                'text': 'mdi-api'
                                            },
                                            {
                                                'component': 'span',
                                                'text': 'API 配置'
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                'component': 'VDivider'
                            },
                            {
                                'component': 'VCardText',
                                'props': {
                                    'class': 'px-6'
                                },
                                'content': [
                                    {
                                        'component': 'VRow',
                                        'content': [
                                            # ThePornDB Token
                                            {
                                                'component': 'VCol',
                                                'props': {'cols': 12, 'sm': 6},
                                                'content': [
                                                    {
                                                        'component': 'VTextField',
                                                        'props': {
                                                            'model': 'theporndb_api_token',
                                                            'label': 'ThePornDB Token',
                                                            'placeholder': '请输入API Token',
                                                            'variant': 'outlined',
                                                            'density': 'compact',
                                                        }
                                                    }
                                                ]
                                            },
                                            # ByteMuse 地址
                                            {
                                                'component': 'VCol',
                                                'props': {'cols': 12, 'sm': 6},
                                                'content': [
                                                    {
                                                        'component': 'VTextField',
                                                        'props': {
                                                            'model': 'bytemuse_base_url',
                                                            'label': 'ByteMuse 地址',
                                                            'placeholder': 'http://10.0.0.1:3750',
                                                            'variant': 'outlined',
                                                            'density': 'compact',
                                                        }
                                                    }
                                                ]
                                            },
                                            # ByteMuse 用户名
                                            {
                                                'component': 'VCol',
                                                'props': {'cols': 12, 'sm': 6},
                                                'content': [
                                                    {
                                                        'component': 'VTextField',
                                                        'props': {
                                                            'model': 'bytemuse_username',
                                                            'label': 'ByteMuse 用户名',
                                                            'placeholder': 'mubey',
                                                            'variant': 'outlined',
                                                            'density': 'compact',
                                                        }
                                                    }
                                                ]
                                            },
                                            # ByteMuse 密码
                                            {
                                                'component': 'VCol',
                                                'props': {'cols': 12, 'sm': 6},
                                                'content': [
                                                    {
                                                        'component': 'VTextField',
                                                        'props': {
                                                            'model': 'bytemuse_password',
                                                            'label': 'ByteMuse 密码',
                                                            'placeholder': '••••••',
                                                            'variant': 'outlined',
                                                            'density': 'compact',
                                                            'type': 'password',
                                                        }
                                                    }
                                                ]
                                            },
                                            # Metatube 地址
                                            {
                                                'component': 'VCol',
                                                'props': {'cols': 12, 'sm': 6},
                                                'content': [
                                                    {
                                                        'component': 'VTextField',
                                                        'props': {
                                                            'model': 'metatube_base_url',
                                                            'label': 'Metatube 地址',
                                                            'placeholder': 'http://10.0.0.1:3244',
                                                            'variant': 'outlined',
                                                            'density': 'compact',
                                                        }
                                                    }
                                                ]
                                            },
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    # 使用说明
                    {
                        'component': 'VCard',
                        'props': {
                            'variant': 'flat',
                            'class': 'mt-3',
                            'color': 'surface'
                        },
                        'content': [
                            {
                                'component': 'VCardItem',
                                'props': {
                                    'class': 'px-6 pb-0'
                                },
                                'content': [
                                    {
                                        'component': 'VCardTitle',
                                        'props': {
                                            'class': 'd-flex align-center text-h6'
                                        },
                                        'content': [
                                            {
                                                'component': 'VIcon',
                                                'props': {
                                                    'style': 'color: #16b1ff;',
                                                    'class': 'mr-2'
                                                },
                                                'text': 'mdi-information'
                                            },
                                            {
                                                'component': 'span',
                                                'text': '使用说明'
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                'component': 'VDivider'
                            },
                            {
                                'component': 'VCardText',
                                'props': {
                                    'class': 'px-6'
                                },
                                'content': [
                                    {
                                        'component': 'div',
                                        'props': {
                                            'class': 'text-body-1'
                                        },
                                        'text': '开启对应探索服务将在MoviePilot探索服务中展示对应探索页面，可根据需要进行开启。'
                                    },
                                    {
                                        'component': 'div',
                                        'props': {
                                            'class': 'text-body-1 mt-2'
                                        },
                                        'text': f'当前聚合模块：{plugin_names}'
                                    },
                                    {
                                        'component': 'div',
                                        'props': {
                                            'class': 'text-body-1 mt-2'
                                        },
                                        'content': [
                                            {
                                                'component': 'span',
                                                'text': '数据源: '
                                            },
                                            {
                                                'component': 'a',
                                                'props': {
                                                    'href': 'https://theporndb.net',
                                                    'target': '_blank',
                                                    'style': 'color: #16b1ff; text-decoration: underline;'
                                                },
                                                'text': 'ThePornDB'
                                            },
                                            {
                                                'component': 'span',
                                                'text': '、'
                                            },
                                            {
                                                'component': 'a',
                                                'props': {
                                                    'href': 'https://github.com/ByteDance/ByteMuse',
                                                    'target': '_blank',
                                                    'style': 'color: #16b1ff; text-decoration: underline;'
                                                },
                                                'text': 'ByteMuse'
                                            },
                                            {
                                                'component': 'span',
                                                'text': '、'
                                            },
                                            {
                                                'component': 'a',
                                                'props': {
                                                    'href': 'https://github.com/xxxhcm2019/metatube',
                                                    'target': '_blank',
                                                    'style': 'color: #16b1ff; text-decoration: underline;'
                                                },
                                                'text': 'Metatube'
                                            },
                                        ]
                                    },
                                    {
                                        'component': 'div',
                                        'props': {
                                            'class': 'text-body-1 mt-2'
                                        },
                                        'text': 'API 端点结构:'
                                    },
                                    {
                                        'component': 'div',
                                        'props': {
                                            'class': 'text-body-2 mt-1'
                                        },
                                        'content': [
                                            {
                                                'component': 'ul',
                                                'props': {'class': 'ml-4'},
                                                'content': [
                                                    {'component': 'li', 'text': '/bytemuse_actors - 演员（订阅中/热门）'},
                                                    {'component': 'li', 'text': '/bytemuse_new_releases - 上新'},
                                                    {'component': 'li', 'text': '/bytemuse_recommendations - 推荐'},
                                                    {'component': 'li', 'text': '/bytemuse_rankings - 榜单（JavDB日榜/周榜/月榜、JavLibrary）'},
                                                    {'component': 'li', 'text': '/bytemuse_studios - 厂牌（9个厂牌）'},
                                                    {'component': 'li', 'text': '/bytemuse_search - 搜索（ThePornDB/ByteMuse/Metatube）'},
                                                ]
                                            }
                                        ]
                                    },
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
        default_data = {
            f"{name}_enabled": False for name in self.modules
        }
        default_data.update({
            "theporndb_api_token": "",
            "bytemuse_base_url": "http://10.0.0.1:3750",
            "bytemuse_username": "mubey",
            "bytemuse_password": "355492",
            "metatube_base_url": "http://10.0.0.1:3244",
        })
        return form, default_data

    def get_api(self) -> List[Dict[str, Any]]:
        """获取API列表"""
        apis = []
        for name, mod in self.modules.items():
            if self.enabled_modules.get(name):
                module_apis = mod.get_api(self)
                if module_apis:
                    apis.extend(module_apis)
        return apis

    def get_page(self) -> List[dict]:
        pass

    @eventmanager.register(ChainEventType.DiscoverSource)
    def discover_source(self, event: Event):
        """注册探索源事件"""
        event_data: DiscoverSourceEventData = event.event_data
        for name, mod in self.modules.items():
            if self.enabled_modules.get(name):
                try:
                    mod.discover_source(self, event_data)
                except Exception as e:
                    logger.error(f"注册 {name} 探索源失败: {str(e)}")

    @eventmanager.register(ChainEventType.MediaRecognizeConvert)
    async def async_media_recognize_convert(self, event: Event):
        """
        监听媒体识别转换事件
        参考 IMDb 插件的 async_media_recognize_covert() 实现

        注意：此处理逻辑独立于模块开关，即使没有启用任何探索模块，
        用户点击 ByteMuse 媒体项时也应能查看详情。
        """
        # 不检查 get_state()，因为详情查看功能应该始终可用
        event_data: MediaRecognizeConvertEventData = event.event_data
        if not event_data:
            logger.debug("[MediaRecognizeConvert] event_data 为空，跳过")
            return

        # 只处理需要详情的场景（不进行实际转换）
        # ByteMuse 数据独立展示，不需要转换为 TMDB
        # 支持多种前缀格式: bytemuse:, bytemuse_rank:, bytemuse_actor:, bytemuse_new:, bytemuse_recommend:, bytemuse_studio:, bytemuse_search:
        if event_data.mediaid and (event_data.mediaid.startswith("bytemuse:") or event_data.mediaid.startswith("bytemuse_")):
            # 提取真实的番号（移除所有 bytemuse 相关前缀）
            # 格式可能是: bytemuse:MNGS-045, bytemuse_rank:MNGS-045, bytemuse_actor:Name
            if event_data.mediaid.startswith("bytemuse:"):
                code = event_data.mediaid.replace("bytemuse:", "", 1)
            else:
                # 处理 bytemuse_*: 格式
                parts = event_data.mediaid.split(":", 1)
                code = parts[1] if len(parts) > 1 else event_data.mediaid.split("_", 1)[1]

            logger.info(f"[MediaRecognizeConvert] ByteMuse 媒体: {code}, mediaid={event_data.mediaid}")

            # 获取详情并填充到 media_dict
            logger.debug(f"[MediaRecognizeConvert] 开始调用 async_recognize_media")
            mediainfo = await self.async_recognize_media(
                meta=MetaBase(name=code),
                mtype=MediaType.MOVIE,
                mediaid=event_data.mediaid
            )
            logger.debug(f"[MediaRecognizeConvert] async_recognize_media 返回: {mediainfo is not None}")

            if mediainfo:
                # 将详情信息填充到事件数据中
                # 格式参考 TMDB/豆瓣的媒体数据
                logger.info(f"[MediaRecognizeConvert] 成功获取详情，填充到 media_dict: title={mediainfo.title}, poster={mediainfo.poster_path}")

                # 获取 directors 和 actors，确保格式正确
                directors = getattr(mediainfo, "directors", [])
                actors = getattr(mediainfo, "actors", [])

                # 如果 directors 是对象列表，提取 name
                if directors and isinstance(directors, list) and all(isinstance(d, dict) for d in directors):
                    directors = [d.get("name", "") for d in directors if d.get("name")]

                event_data.media_dict.update({
                    "type": mediainfo.type,
                    "title": mediainfo.title,
                    "overview": mediainfo.overview,
                    "poster_path": mediainfo.poster_path,
                    "backdrop_path": getattr(mediainfo, "backdrop_path", ""),  # 背景图
                    "vote_average": mediainfo.vote_average,
                    "year": mediainfo.year,
                    "studio": getattr(mediainfo, "studio", ""),
                    "directors": directors,
                    "actors": actors,
                    "genres": getattr(mediainfo, "genres", []),  # 类型标签
                    "runtime": getattr(mediainfo, "runtime", None),  # 时长
                })
                logger.debug(f"[MediaRecognizeConvert] media_dict 已更新: {list(event_data.media_dict.keys())}")
            else:
                logger.warning(f"[MediaRecognizeConvert] 未获取到媒体详情: {code}")

    def stop_service(self):
        """停止服务"""
        for name, mod in self.modules.items():
            if hasattr(mod, "stop_service"):
                try:
                    mod.stop_service()
                except Exception as e:
                    logger.error(f"停止 {name} 模块服务失败: {str(e)}")

    # ===== 属性访问器 =====

    @property
    def theporndb_api_token(self) -> str:
        return self._theporndb_api_token

    @property
    def bytemuse_base_url(self) -> str:
        return self._bytemuse_base_url

    @property
    def bytemuse_username(self) -> str:
        return self._bytemuse_username

    @property
    def bytemuse_password(self) -> str:
        return self._bytemuse_password

    @property
    def metatube_base_url(self) -> str:
        return self._metatube_base_url

    def recognize_media(self, meta: MetaBase = None,
                        mtype: MediaType = None,
                        **kwargs) -> Optional[MediaInfo]:
        """
        识别媒体信息（智能处理 ByteMuse mediaid 点击）

        采用混合模式：
        1. 特殊场景（种子、演员、ThePornDB）必须拦截处理
        2. 只处理明确的成人内容（JAV 番号格式）
        3. 其他内容返回 None，使用默认流程以整合 TMDB/Douban 等数据源

        :param meta: 识别的元数据
        :param mtype: 识别的媒体类型
        :return: 识别的媒体信息
        """
        if not meta:
            logger.debug("recognize_media: meta 为空，返回 None")
            return None

        # 从 kwargs 中获取 mediaid 信息
        mediaid = kwargs.get("mediaid", "")
        imdb_id = kwargs.get("imdb_id", "")

        # 只在调试模式下显示详细日志
        logger.debug(f"recognize_media 被调用: mediaid={mediaid}, imdb_id={imdb_id}")

        # ========== 1. 特殊场景：种子下载 - 必须拦截 ==========
        if mediaid and mediaid.startswith("bytemuse_torrent:"):
            code = mediaid.split(":", 1)[1]
            logger.info(f"recognize_media: 识别为种子下载")
            return self._handle_torrent_download(code)

        # ========== 2. 特殊场景：演员点击 - 必须拦截 ==========
        if mediaid and mediaid.startswith("bytemuse_actor:"):
            code = mediaid.split(":", 1)[1]
            logger.info(f"recognize_media: 识别为演员点击: {code}")
            return self._fetch_actor_info(code)

        # ========== 3. 特殊场景：ThePornDB JAV - 需要拦截（TMDB 没有数据）==========
        if imdb_id and imdb_id.startswith("theporndb:"):
            code = imdb_id.replace("theporndb:", "", 1)
            logger.info(f"recognize_media: 从 imdb_id 识别 ThePornDB 番号: {code}")
            return self._fetch_theporndb_detail(code)

        # ========== 4. 检查是否是 ByteMuse 的 imdb_id 格式 ==========
        if imdb_id and imdb_id.startswith("bytemuse:"):
            code = imdb_id.replace("bytemuse:", "", 1)
            logger.info(f"recognize_media: 从 imdb_id 识别 ByteMuse 番号: {code}")
            return self._fetch_bytemuse_detail(code)

        # ========== 5. ByteMuse 各种前缀格式处理 ==========
        # 支持多种前缀: bytemuse:, bytemuse_rank:, bytemuse_recommendations:, bytemuse_new_releases:, 等
        if mediaid and (mediaid.startswith("bytemuse:") or mediaid.startswith("bytemuse_")):
            # 解析真实的番号（移除所有 bytemuse 前缀）
            code = self._extract_code_from_mediaid(mediaid)
            if code:
                logger.info(f"recognize_media: ByteMuse 媒体点击: {mediaid} -> {code}")
                return self._fetch_bytemuse_detail(code)

        # ========== 6. 演员点击（已在前面的 bytemuse_actor: 处理，这里保留以防万一）==========
        # 代码已合并到上面的通用处理中

        # ========== 7. 其他情况：内容类型判断 ==========
        title = meta.org_string or meta.cn_name or meta.en_name or meta.name or ""
        if not title:
            logger.debug("recognize_media: 无法获取标题，返回 None")
            return None

        # 判断是否为成人内容（JAV 番号格式）
        # JAV 番号特征：字母-数字组合，如 SSIS-123, OFJE-620 等
        if self._is_jav_number(title):
            logger.info(f"recognize_media: 检测到 JAV 番号格式，从 ByteMuse 搜索: {title}")
            return self._fetch_bytemuse_detail(title)

        # 判断是否包含明显的成人内容标识
        adult_keywords = [
            # 番号格式（包含中文）
            "七ツ森りり", "奥田咲",  # 演员名
            # 制作商标识
            "S1", "Moodyz", "IdeaPocket", "Prestige", "Alice JAPAN",
            "kawaii", "E-BODY", "OPPAI", "Wanz Factory",
            # 其他标识
            "JAV", "FANZA", "DMM",
        ]

        is_adult_content = any(keyword in title for keyword in adult_keywords)

        if is_adult_content:
            logger.info(f"recognize_media: 检测到成人内容标识，从 ByteMuse 搜索: {title}")
            return self._fetch_bytemuse_detail(title)

        # ========== 7. 非成人内容 - 使用默认流程 ==========
        # 包括：国产电视剧、纪录片、普通电影、欧美剧等
        logger.debug(f"recognize_media: 非成人内容，使用默认识别流程: {title}")
        return None  # 让 MoviePilot 使用 TMDB/Douban 识别

    async def async_recognize_media(self, meta: MetaBase = None,
                                   mtype: MediaType = None,
                                   **kwargs) -> Optional[MediaInfo]:
        logger.debug(f"[async_recognize_media] 开始: meta={meta.name if meta else None}, mtype={mtype}, kwargs={kwargs}")

        if not meta:
            logger.debug("[async_recognize_media] meta 为空，返回 None")
            return None

        mediaid = kwargs.get("mediaid", "")
        imdb_id = kwargs.get("imdb_id", "")

        logger.debug(f"[async_recognize_media] mediaid={mediaid}, imdb_id={imdb_id}")

        # ByteMuse 各种前缀格式处理（统一处理）
        # 支持多种前缀: bytemuse:, bytemuse_rank:, bytemuse_recommendations:, bytemuse_new_releases:, bytemuse_actor: 等
        if mediaid and (mediaid.startswith("bytemuse:") or mediaid.startswith("bytemuse_")):
            # 检查是否是演员
            if mediaid.startswith("bytemuse_actor:"):
                actor_name = mediaid.split(":", 1)[1]
                logger.info(f"[async_recognize_media] ByteMuse 演员: {actor_name}")
                return self._fetch_actor_info(actor_name)
            else:
                # 其他媒体类型（排名、推荐、上新等）
                code = self._extract_code_from_mediaid(mediaid)
                logger.info(f"[async_recognize_media] ByteMuse 媒体: {mediaid} -> {code}")
                if code:
                    logger.debug(f"[async_recognize_media] 调用 _async_fetch_bytemuse_detail: {code}")
                    result = await self._async_fetch_bytemuse_detail(code)
                    logger.debug(f"[async_recognize_media] _async_fetch_bytemuse_detail 返回: {result is not None}")
                    return result

        # ThePornDB
        if imdb_id and imdb_id.startswith("theporndb:"):
            code = imdb_id.replace("theporndb:", "", 1)
            logger.info(f"[async_recognize_media] ThePornDB 番号: {code}")
            return await self._async_fetch_theporndb_detail(code)

        return self.recognize_media(meta, mtype, **kwargs)

    def _extract_code_from_mediaid(self, mediaid: str) -> Optional[str]:
        """
        从 mediaid 中提取真实的番号

        支持多种格式：
        - bytemuse:MNGS-045 -> MNGS-045
        - bytemuse_rank:MNGS-045 -> MNGS-045
        - bytemuse_recommendations:MNGS-045 -> MNGS-045
        - bytemuse_new_releases:MNGS-045 -> MNGS-045
        - bytemuse_actor:Name -> Name

        :param mediaid: 媒体ID
        :return: 提取的番号或演员名
        """
        if not mediaid:
            return None

        # 处理 bytemuse: 格式
        if mediaid.startswith("bytemuse:"):
            return mediaid.replace("bytemuse:", "", 1)

        # 处理 bytemuse_*: 格式
        if ":" in mediaid:
            parts = mediaid.split(":", 1)
            if len(parts) == 2:
                return parts[1]

        # 如果没有冒号，尝试从下划线后提取
        if "_" in mediaid:
            parts = mediaid.split("_", 1)
            if len(parts) == 2:
                return parts[1]

        # 无法提取，返回原值（可能已经是纯番号）
        return mediaid

    def _is_jav_number(self, text: str) -> bool:
        """
        检测文本是否像 JAV 番号格式

        :param text: 待检测文本
        :return: 是否像番号
        """
        if not text:
            return False

        import re
        # JAV 番号常见格式：字母-数字，如 SSIS-123, ABC-123
        pattern = r'^[A-Z]{2,6}-?\d{3,5}$'
        return bool(re.match(pattern, text.strip().upper()))

    def _handle_torrent_download(self, magnet_b64: str) -> Optional[MediaInfo]:
        """
        处理种子下载（点击种子时触发）

        :param magnet_b64: base64 编码的磁力链接
        :return: 媒体信息
        """
        import base64
        import requests
        from app.core.config import settings

        try:
            # 解码磁力链接
            magnet = base64.b64decode(magnet_b64).decode()
            logger.info(f"触发种子下载: {magnet[:50]}...")

            # 调用 MoviePilot 的下载 API
            api_url = f"{settings.API_URL}/api/v1/download"
            headers = {
                "Authorization": f"Bearer {settings.API_TOKEN}",
                "Content-Type": "application/json"
            }

            payload = {
                "url": magnet,
                "type": "torrent"
            }

            response = requests.post(api_url, json=payload, headers=headers, timeout=10)

            if response.status_code == 200:
                logger.info(f"种子下载添加成功: {magnet[:50]}...")
                return MediaInfo(
                    type="电影",
                    title="✓ 下载已添加",
                    overview="种子已添加到下载队列，请在下载中心查看",
                    poster_path="",
                )
            else:
                logger.warning(f"种子下载添加失败: {response.status_code} - {response.text}")
                return MediaInfo(
                    type="电影",
                    title="✗ 下载失败",
                    overview=f"错误: {response.status_code} - {response.text[:100]}",
                    poster_path="",
                )

        except Exception as err:
            logger.error(f"种子下载失败: {str(err)}")
            return MediaInfo(
                type="电影",
                title="✗ 下载失败",
                overview=f"错误: {str(err)}",
                poster_path="",
            )

    def _fetch_actor_info(self, actor_name: str) -> Optional[MediaInfo]:
        """
        获取演员信息（点击演员时显示）

        :param actor_name: 演员名
        :return: 媒体信息
        """
        if not actor_name:
            return None

        # 返回演员信息，title 设置为演员名
        return MediaInfo(
            type="电视剧",
            title=actor_name,
            mediaid_prefix="bytemuse_actor",
            media_id=actor_name,
            imdb_id=f"bytemuse_actor:{actor_name}",
            overview=f"点击查看 {actor_name} 的作品列表",
        )

    def _fetch_bytemuse_detail(self, code: str) -> Optional[MediaInfo]:
        """
        从 ByteMuse API 获取详情

        :param code: 番号
        :return: 媒体信息
        """
        if not code:
            logger.warning("ByteMuse 详情获取失败: 番号为空")
            return None

        if not self._bytemuse_username or not self._bytemuse_password:
            logger.warning("ByteMuse 详情获取失败: 未配置用户名或密码")
            return None

        try:
            from .bytemuse_api import ByteMuseApiClient
            from .schema import ByteMuseMovie

            logger.info(f"ByteMuse 详情获取: 开始搜索番号 {code}")

            client = ByteMuseApiClient(
                base_url=self._bytemuse_base_url,
                username=self._bytemuse_username,
                password=self._bytemuse_password,
            )

            # 使用搜索接口获取详情
            result = client.search_by_code(query=code)

            if not result:
                logger.warning(f"ByteMuse 详情获取失败: API 未返回结果, code={code}")
                return None

            # 解析返回的数据
            codes = result.get("codes", [])
            if not codes:
                logger.warning(f"ByteMuse 详情获取失败: codes 列表为空, code={code}")
                return None

            # 取第一个匹配结果
            movie_data = codes[0]

            # 转换为 ByteMuseMovie
            movie = ByteMuseMovie(**movie_data)

            logger.info(f"ByteMuse 详情获取成功: {code} -> {movie.title}")

            # 转换为 MediaInfo
            return self._movie_to_media(movie)

        except Exception as err:
            logger.error(f"ByteMuse 详情获取失败: {str(err)}")
            import traceback
            logger.debug(f"ByteMuse 详情获取异常详情: {traceback.format_exc()}")
            return None

    def _movie_to_media(self, movie) -> MediaInfo:
        """
        将 ByteMuseMovie 转换为 MediaInfo（增强版）

        :param movie: ByteMuseMovie 对象
        :return: MediaInfo 对象
        """
        from .schema import ByteMuseMovie

        if not isinstance(movie, ByteMuseMovie):
            # 如果是字典，先转换为 ByteMuseMovie
            if isinstance(movie, dict):
                movie = ByteMuseMovie(**movie)
            else:
                return MediaInfo()

        # ========== 1. 提取演员信息 ==========
        actor_names = []
        if movie.actors:
            actor_names = [actor.name for actor in movie.actors if actor.name]
        elif movie.casts:
            actor_names = [name.strip() for name in movie.casts.split(',') if name.strip()]

        # ========== 2. 提取标签/类型信息 ==========
        genres = []
        if movie.genres:
            if isinstance(movie.genres, str):
                genres = [g.strip() for g in movie.genres.split(',') if g.strip()]
            elif isinstance(movie.genres, list):
                genres = movie.genres

        # ========== 3. 提取导演信息 ==========
        directors_list = []
        if movie.director:
            directors_list = [movie.director]

        # ========== 4. 构建标题（优先显示标题，番号作为副标题）==========
        display_title = movie.title or movie.cn_title or movie.code or ""

        # ========== 5. 确保 media_id 永远不为空 ==========
        if movie.code:
            media_id = movie.code
        elif movie.id:
            media_id = f"bytemuse_{movie.id}"
        else:
            media_id = display_title or f"unknown_{id(movie)}"

        # ========== 6. 提取年份 ==========
        year = None
        if movie.release_date:
            try:
                year = movie.release_date[:4]
            except (IndexError, TypeError):
                pass

        # ========== 7. 提取厂牌/发行商 ==========
        studio = movie.studio or movie.publisher or ""

        # ========== 8. 构建 MediaInfo ==========
        mediainfo = MediaInfo(
            type="电影",
            title=display_title,  # 显示标题
            mediaid_prefix="bytemuse",
            media_id=media_id,
            imdb_id=f"bytemuse:{movie.code}" if movie.code else f"bytemuse:{media_id}",
            poster_path=movie.poster_url or movie.cover_url or movie.thumb_url or "",
            vote_average=movie.score,
            year=year,
            overview=movie.summary or f"番号: {movie.code}",  # 添加番号到简介
            studio=studio,
            directors=directors_list,  # ✅ 字符串列表
            actors=actor_names,        # ✅ 字符串列表
            genres=genres,             # ✅ 添加标签
        )

        # ========== 9. 添加额外信息（使用属性赋值）==========
        if actor_names:
            mediainfo.actor = [{"name": name} for name in actor_names]

        if movie.series:
            mediainfo.series = movie.series

        if movie.label:
            mediainfo.label = movie.label

        # 时长
        if movie.runtime:
            mediainfo.runtime = movie.runtime
        elif movie.duration:
            mediainfo.runtime = movie.duration // 60  # 转换为分钟

        # 预览图
        if movie.preview_url:
            mediainfo.backdrop_path = movie.preview_url
        if movie.thumb_url:
            mediainfo.thumb_path = movie.thumb_url

        return mediainfo

    def _fetch_theporndb_detail(self, code: str) -> Optional[MediaInfo]:
        """
        从 ThePornDB API 获取详情

        :param code: 番号
        :return: 媒体信息
        """
        if not code:
            return None

        if not self._theporndb_api_token:
            logger.warning("ThePornDB 详情获取失败: 未配置 API Token")
            return None

        try:
            from .theporndb_api import ThePornDBApiClient
            from .schema import ThePornDBJAVDetail

            client = ThePornDBApiClient(api_token=self._theporndb_api_token)

            # 使用 JAV 详情 API 获取详情
            detail = client.get_jav_detail(code)

            if not detail:
                logger.warning(f"ThePornDB 未找到番号: {code}")
                return None

            logger.info(f"ThePornDB 详情获取成功: {code} -> {detail.title}")

            # 转换为 MediaInfo
            code_value = detail.external_id or ""

            # 提取海报图片
            poster_url = ""
            if detail.background:
                if hasattr(detail.background, 'url') and detail.background.url:
                    poster_url = detail.background.url
                elif hasattr(detail.background, 'large') and detail.background.large:
                    poster_url = detail.background.large

            # 厂牌信息
            studio = ""
            if detail.site:
                if hasattr(detail.site, 'name') and detail.site.name:
                    studio = detail.site.name

            # 年份
            year = None
            if detail.date:
                try:
                    year = detail.date[:4]
                except (IndexError, TypeError):
                    pass

            return MediaInfo(
                type="电影",
                title=code_value if code_value else detail.title[:50],
                mediaid_prefix="theporndb_jav",
                media_id=code_value,
                imdb_id=f"theporndb:{code_value}" if code_value else "",
                poster_path=poster_url,
                vote_average=None,
                year=year,
                overview=detail.description or detail.title or "",
                studio=studio,
            )

        except Exception as err:
            logger.error(f"ThePornDB 详情获取失败: {str(err)}")
            return None

    async def _async_fetch_bytemuse_detail(self, code: str) -> Optional[MediaInfo]:
        import asyncio
        from concurrent.futures import ThreadPoolExecutor
        try:
            loop = asyncio.get_event_loop()
            with ThreadPoolExecutor() as pool:
                result = await loop.run_in_executor(pool, self._fetch_bytemuse_detail, code)
            return result
        except Exception as err:
            logger.error(f"[异步] ByteMuse 详情获取失败: {str(err)}")
            return None

    async def _async_fetch_theporndb_detail(self, code: str) -> Optional[MediaInfo]:
        import asyncio
        from concurrent.futures import ThreadPoolExecutor
        try:
            loop = asyncio.get_event_loop()
            with ThreadPoolExecutor() as pool:
                result = await loop.run_in_executor(pool, self._fetch_theporndb_detail, code)
            return result
        except Exception as err:
            logger.error(f"[异步] ThePornDB 详情获取失败: {str(err)}")
            return None
